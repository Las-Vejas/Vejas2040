# Vejas2040
an RP2040 devboard made by me

What it includes:
- RP2040
- 1 Neopixel LED
- 2 buttons
- a pico form factor

Here are some images of the board (3d files):

<img width="638" height="193" alt="SCR-20251012-igse" src="https://github.com/user-attachments/assets/418c61ca-1d42-456c-a10a-fd0882e04b02" />
<img width="269" height="622" alt="SCR-20251012-igog" src="https://github.com/user-attachments/assets/152a620a-e32b-4e6f-8583-e03100ec9d9e" />
<img width="269" height="619" alt="SCR-20251012-igli" src="https://github.com/user-attachments/assets/1096e5ce-98fa-4393-8f68-788517a1be26" />
